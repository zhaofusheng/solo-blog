title: JAVA关于Spring 面试题汇总
date: '2019-11-13 16:09:47'
updated: '2019-11-13 16:27:21'
tags: [Spring, spring面试题]
permalink: /articles/2019/11/13/1573632587451.html
---
![](https://img.hacpai.com/bing/20190417.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



## 1 Spring 框架有哪些主要模块？
截止到目前Spring 框架已集成了 20 多个模块 。 这些模块主要被分如下图所示的核心容器 、 数据访问 / 集成 、Web、AOP （面向切面编程） 、 工具 、 消息和测试模块 。

如图：
![null](https://img-blog.csdn.net/20180828154641214?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM3ODQwOTkz/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
## 2 什么是依赖注入？什么是控制反转(IOC)？ 在 Spring 中，有几种依赖注入方式？
依赖注入是在编译阶段尚未知所需的功能是来自哪个的类的情况下，将其他对象所依赖的功能对象实例化的模式。

在传统的编程方式中，业务逻辑的流程是由应用程序中的早已被设定好关联关系的对象来决定的。在使用控制反转的情况下，业务逻辑的流程是由对象关系图来决定的，该对象关系图由装配器负责实例化，这种实现方式还可以将对象之间的关联关系的定义抽象化。而绑定的过程是通过“依赖注入”实现的。

注入方式： 
* 构造器注入 
* Setter方法注入 
* 接口注入

## 3 在 Spring 中，有几种配置 Bean 的方式？
基于XML的配置
基于注解的配置
基于Java的配置
## 4 请解释一下 Spring Bean 的生命周期？
在一个 bean 实例被初始化时，需要执行一系列的初始化操作以达到可用的状态 。 同样的，当一个 bean 不在被调用时需要进行相关的析构操作，并从 bean 容器中移除 。 
Spring bean factory 负责管理在 spring 容器中被创建的 bean 的生命周期 。Bean 的生命周期由两组回调（call back）方法组成 。 
初始化之后调用的回调方法。 
销毁之前调用的回调方法。

Spring 框架提供了以下四种方式来管理 bean 的生命周期事件： 
* InitializingBean 和 DisposableBean 回调接口 
* 针对特殊行为的其他 Aware 接口 
* Bean 配置文件中的 Custom init() 方法和 destroy() 方法 
* @PostConstruct 和 @PreDestroy 注解方式

## 5 Spring Bean 有哪些作用域，它们之间有什么区别？
singleton ：这种 bean 范围是默认的，这种范围确保不管接受到多少个请求，每个容器中只有一个 bean 的实例，单例的模式由 bean factory 自身来维护 。
prototype ：原形范围与单例范围相反，为每一个 bean 请求提供一个实例 。
request ：在请求 bean 范围内会每一个来自客户端的网络请求创建一个实例，在请求完成以后， bean 会失效并被垃圾回收器回收 。
Session ：与请求范围类似，确保每个 session 中有一个 bean 的实例，在 session 过期后， bean 会随之失效 。
global-session ： global-session 和 Portlet 应用相关 。 当你的应用部署在 Portlet 容器中工作时，它包含很多 portlet。 如果你想要声明让所有的 portlet 共用全局的存储变量的话，那么这全局变量需要存储在 global-session 中 。
## 6 Spring 框架中的单例 Beans 是线程安全的么？
实际上，大部分的 Spring bean 并没有可变的状态 ( 比如 Service 类和 DAO 类 ) ，所以在某种程度上说 Spring 的单例 bean 是线程安全的 。 如果你的 bean 有多种状态的话（比如 View Model 对象），就需要自行保证线程安全 。

## 7 请解释一下，Spring 框架有哪些自动装配模式，它们之间有何区别？
no ：这是 Spring 框架的默认设置，在该设置下自动装配是关闭的，开发者需要自行在 bean 定义中用标签明确的设置依赖关系 。
byName ：该选项可以根据 bean 名称设置依赖关系 。 当向一个 bean 中自动装配一个属性时，容器将根据 bean 的名称自动在在配置文件中查询一个匹配的 bean。 如果找到的话，就装配这个属性，如果没找到的话就报错 。
byType ：该选项可以根据 bean 类型设置依赖关系 。 当向一个 bean 中自动装配一个属性时，容器将根据 bean 的类型自动在在配置文件中查询一个匹配的 bean。 如果找到的话，就装配这个属性，如果没找到的话就报错 。
constructor ：构造器的自动装配和 byType 模式类似，但是仅仅适用于与有构造器相同参数的 bean ，如果在容器中没有找到与构造器参数类型一致的 bean ，那么将会抛出异常 。
autodetect ：该模式自动探测使用构造器自动装配或者 byType 自动装配 。 首先，首先会尝试找合适的带参数的构造器，如果找到的话就是用构造器自动装配，如果在 bean 内部没有找到相应的构造器或者是无参构造器，容器就会自动选择 byTpe 的自动装配方式 。
## 8 Spring 框架中用到了哪些设计模式？请举例说明
Spring 框架中使用到了大量的设计模式，下面列举了比较有代表性的：

代理模式 — 在 AOP 和 remoting 中被用的比较多 。

单例模式 — 在 spring 配置文件中定义的 bean 默认为单例模式 。

模板方法 — 用来解决代码重复的问题 。 比如 RestTemplate,   JmsTemplate,   JpaTemplate。

前端控制器 —Spring 提供了 DispatcherServlet 来对请求进行分发 。

视图帮助 (View Helper   )—Spring 提供了一系列的 JSP 标签，高效宏来辅助将分散的代码整合在视图里 。

依赖注入 — 贯穿于 BeanFactory   /   ApplicationContext 接口的核心理念 。

工厂模式 —BeanFactory 用来创建对象的实例 。

## 9 说说 Springmvc 有哪些优点？
它是基于组件技术的 . 全部的应用对象 , 无论控制器和视图 , 还是业务对象之类的都是 java 组件 . 并且和 Spring 提供的其他基础结构紧密集成 .
不依赖于 Servlet API( 目标虽是如此 , 但是在实现时确实是依赖于 Servlet 的 )
可以任意使用各种视图技术 , 而不仅仅局限于 JSP
支持各种请求资源的映射策略
它应是易于扩展的
## 10 Spring 框架的事务管理有哪些优点？
它为不同的事务 API 如 JTA ， JDBC ， Hibernate ， JPA 和 JDO ，提供一个不变的编程模式 。
它为编程式事务管理提供了一套简单的 API 而不是一些复杂的事务 API。
它支持声明式事务管理 。
它和 Spring 各种数据访问抽象层很好的集成 。
## 11 AOP 的应用场景、原理 、AOP 好处？
AOP–Aspect Oriented Programming 面向切面编程；用来封装横切关注点，具体可以在下面的场景中使用:

Authentication 权限
Caching 缓存
Context passing 内容传递
Error handling 错误处理
Lazy loading 懒加载
Debugging 调试
logging, tracing, profiling and monitoring 记录跟踪优化校准
Performance optimization 　性能优化
Persistence 持久化
Resource pooling 　资源池
Synchronization 　同步
Transactions 事务
原理： AOP 是面向切面编程，是通过动态代理的方式为程序添加统一功能，集中解决一些公共问题 。

优点： 
* 各个步骤之间的良好隔离性耦合性大大降低 。 
* 源代码无关性，再扩展功能的同时不对源码进行修改操作。

## 12 Spring 中常见的创建对象的注解有哪些？
@Component
@Controller
@Service
@Repository
## 13 Spring 管理事务的方式有几种？
### 1、编程式事务，在代码中硬编码。(不推荐使用)

### 2、声明式事务，在配置文件中配置（推荐使用）

声明式事务又分为两种：

a、基于XML的声明式事务

b、基于注解的声明式事务

##14 spring 中的核心类有那些，各有什么作用？
BeanFactory：产生一个新的实例，可以实现单例模式。

BeanWrapper：提供统一的 get 及 set 方法。

ApplicationContext：提供框架的实现，包括 BeanFactory 的所有功能。

## 15 spring 中有哪些代理方式？实现原理是什么？这些方式的优缺点是什么？
### 1、若目标对象实现了若干接口， spring 使用 JDK 的 java.lang.reflect.Proxy 类代理 。

优点：因为有接口，所以使系统更加松耦合

缺点：为每一个目标类创建接口
### 2、若目标对象没有实现任何接口， spring 则使用 CGLIB 库生成目标对象的子类 。

优点：因为代理类与目标类是继承关系，所以不需要有接口的存在 。

缺点：因为没有使用接口，所以系统的耦合性没有使用 JDK 的动态代理好 。

## 16 说说 IoC 容器的初始化过程？
Resource 定位：我们一般使用外部资源来描述 Bean 对象，所以 IOC 容器第一步就是需要定位 Resource 外部资源 。Resource 的定位其实就是 BeanDefinition 的资源定位，它是由 ResourceLoader 通过统一的 Resource 接口来完成的，这个 Resource 对各种形式的 BeanDefinition 的使用都提供了统一接口 。
载入：第二个过程就是 BeanDefinition 的载入 ,BeanDefinitionReader 读取 , 解析 Resource 定位的资源，也就是将用户定义好的 Bean 表示成 IOC 容器的内部数据结构也就是 BeanDefinition, 在 IOC 容器内部维护着一个 BeanDefinition Map 的数据结构，通过这样的数据结构， IOC 容器能够对 Bean 进行更好的管理 。 在配置文件中每一个都对应着一个 BeanDefinition 对象 。
注册：第三个过程则是注册，即向 IOC 容器注册这些 BeanDefinition ，这个过程是通过 BeanDefinitionRegistery 接口来实现的 。
## 17 说说 BeanFactory 和 ApplicationContext 的区别？ 什么是延迟实例化，它的优缺点是什么？
BeanFactory 是 Spring 里面最低层的接口，提供了最简单的容器的功能，只提供了实例化对象和获取对象的功能 。

两者装载 bean 的区别 
* BeanFactory ：在启动时不会去实例化 Bean ，只有从容器中获取 Bean 时才会去实例化。 
* ApplicationContext ：在启动的时候就把所有的 Bean 全部实例化了 。 它还可以为 Bean 配置 lazy-init=true 来让 Bean 延迟实例化。

延迟实例化 
优点： 应用启动时占用资源很少，对资源要求较高的应用，比较有优势。 
缺点：速度会相对来说慢一些 。 而且有可能会出现空指针异常的错误，而且通过 bean 工厂创建的 bean 生命周期会简单一些。 所有的 Bean 在启动的时候都加载，系统运行的速度快，而且可以尽早的发现系统中的配置问题 。

建议 web 应用，在启动的时候就把所有的 Bean 都加载了 。

## 18 说说 AOP 的实现原理？动态代理的方式有哪些？
Spring AOP 使用的是动态代理，所谓的动态代理就是说 AOP 框架不会去修改字节码，而是在内存中临时为方法生成一个 AOP 对象，这个 AOP 对象包含了目标对象的全部方法，并且在特定的切点做了增强处理，并回调原对象的方法 。

Spring AOP 中的动态代理主要有两种方式， JDK 动态代理和 CGLIB 动态代理 。 
* JDK 动态代理通过反射来接收被代理的类，并且要求被代理的类必须实现一个接口 。JDK 动态代理的核心是 InvocationHandler 接口和 Proxy 类 。 
* 如果目标类没有实现接口，那么 Spring AOP 会选择使用 CGLIB 来动态代理目标类 。CGLIB （ Code Generation Library ），是一个代码生成的类库，可以在运行时动态的生成某个类的子类，注意， CGLIB 是通过继承的方式做的动态代理，因此如果某个类被标记为 final ，那么它是无法使用 CGLIB 做动态代理的 。
————————————————

原文链接：https://blog.csdn.net/qq_37840993/article/details/82149095
