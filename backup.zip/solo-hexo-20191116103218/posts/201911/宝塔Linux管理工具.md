title: 宝塔Linux管理工具
date: '2019-11-13 17:19:05'
updated: '2019-11-13 17:19:33'
tags: [宝塔, 一键式nginx安装, Linux管理工具]
permalink: /articles/2019/11/13/1573636745775.html
---
![](https://img.hacpai.com/bing/20190110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、前言：
宝塔Linux面板是提升运维效率的服务器管理软件，支持一键LAMP/LNMP/集群/监控/网站/FTP/数据库/JAVA等100多项服务器管理功能。  
有20个人的专业团队研发及维护，经过200多个版本的迭代，功能全，少出错且足够安全，已获得全球百万用户认可安装。运维要高效，装宝塔。
![image.png](https://img.hacpai.com/file/2019/11/image-c292232e.png)

### 二、安装
	yum install -y wget && wget -O install.sh [http://download.bt.cn/install/install_6.0.sh](http://download.bt.cn/install/install_6.0.sh) && sh install.sh
注意：安装完需要保存访问地址和用户密码（只有安装的时候会出现一次，必须要保存），并且在云外网安全组内添加8888端口开放，在使用完了需要将8888端口再次关闭，以防被攻击
![image.png](https://img.hacpai.com/file/2019/11/image-4f2b1686.png)

