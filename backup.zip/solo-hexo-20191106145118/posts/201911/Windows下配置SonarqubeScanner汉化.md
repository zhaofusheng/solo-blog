title: Windows下配置Sonarqube+Scanner（汉化）
date: '2019-11-05 14:49:09'
updated: '2019-11-05 14:54:21'
tags: [Sonar, Scanner, sonarqube汉化, sonarqube安装配置]
permalink: /articles/2019/11/05/1572936549092.html
---
![](https://img.hacpai.com/bing/20181215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


## 一、前言

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;网上提供了很多安装以及汉化文章，这里我主要分享自己在安装和汉化过程中的一些步骤和遇到的问题解决过程，如有理解得不对的地方欢迎指正。
## 二、说明
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;此处说明一下，sonarqube8.0不支持mysql，如果需要用到mysql的朋友们建议使用8.0以下的版本，而这里支持的mysql版本是5.6以上的版本都支持。

## 三、下载
这里以Mysql5.7、sonarqube7.0、sonar-scanner-cli-4.2.0.1873为例。
### 1、下载sonarqube
a、最新版官网地址：[https://www.sonarqube.org/downloads/](https://www.sonarqube.org/downloads/)
b、百度云盘：[https://pan.baidu.com/s/1qCTXAHhFvuurpwibHIG8eQ](https://pan.baidu.com/s/1qCTXAHhFvuurpwibHIG8eQ) 	提取码：xkyr
### 2、下载sonar-scanner
a、最新版官网地址：[https://docs.sonarqube.org/latest/analysis/scan/sonarscanner/](https://docs.sonarqube.org/latest/analysis/scan/sonarscanner/)
b、百度云盘：[https://pan.baidu.com/s/15ZcZWVRaUKs42EwRg2kxFQ](https://pan.baidu.com/s/15ZcZWVRaUKs42EwRg2kxFQ)	提取码：qzk0

## 四、安装
### 1、安装sonarqube
 1）、在任意目录下解压sonarqube-7.0.zip，这里我放在D盘
![sonarqube安装目录](https://img-blog.csdnimg.cn/20191017173158838.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
2）、进入conf目录的 sonar.properties 修改相应配置，这里我使用的是mysql5.7，在启动前需要新建 sonar 数据库，否则会启动失败，因为在启动的时候会默认去创建所需的表结构

```java
sonar.jdbc.username=root
sonar.jdbc.password=root
sonar.jdbc.url=jdbc:mysql://localhost:3306/sonar?useUnicode=true&characterEncoding=utf8&rewriteBatchedStatements=true&useConfigs=maxPerformance&useSSL=false

#配置web端口
sonar.web.port=9000
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017173933613.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017173852521.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
3）、确保jdk的环境变量已经配置完成，否则需要到wrapper.conf文件中指定启动的配置
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017174400744.png)
4）、配置修改完成后，到bin目录下启动服务，此处我选择的是：sonarqube-7.0\bin\windows-x86-64
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017174540854.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
第一次启动有点慢，会去插入表
5）、出现以下画面说明启动成功
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017174648768.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
6）、等数据库表都创建成功就可以正常访问了
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019101717474966.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
7）、在浏览器输入 [http://localhost:9000](http://localhost:9000)进行访问，用户名密码都是admin。
第一次登录会看到 Tutorial，按照提示设置用于验证身份的token。*生成的 token需要复制记下来！不会再显示第二次！* 在 _**用户 > 我的账户 > 安全**_ 中可以生成新token（令牌），或者回收已创建的 token。
>如果想强化安全，不想在执行代码扫描或调用Web Service时使用真实SonarQube用户的密码，可以使用用户令牌来代替用户登录。这样可以通过避免把分析用户的密码在网络传输，从而提升安全性。

### 2、安装scanner
1）、将下载好的文件 sonar-scanner-cli-4.2.0.1873-windows.zip解压到任意目录。
2）、配置windows系统环境变量
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017180345995.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019101718042088.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzIyNjYwMDkz,size_16,color_FFFFFF,t_70)
3）、添加扫描的项目，window+r打开cmd，到需要扫描的项目下执行命令

```java
sonar-scanner.bat -Dsonar.projectKey=myproject -Dsonar.sources=. -Dsonar.host.url=http://localhost:9000 -Dsonar.login=(已创建的token)
```
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191017181210503.png)
说明项目扫描完成，在页面管理端就可看到项目的分析报告了
4）、如需重新扫描项目，重新执行上一步骤即可
5）、当然，每次执行那么长一条命令让人困惑，这里可以在scanner的conf目录下修改配置文件 sonar-scanner.properties

```java
# your authentication token
sonar.login=[之前生成的token]

# must be unique in a given SonarQube instance
sonar.projectKey=[项目key]
# this is the name and version displayed in the SonarQube UI. Was mandatory prior to SonarQube 6.1.
sonar.projectName=[项目名称]
sonar.projectVersion=1.0

# Path is relative to the sonar-project.properties file. Replace "\" by "/" on Windows.
# This property is optional if sonar.modules is set. 
# Comma-separated paths to directories containing source files.
# 设置要分析的路径
sonar.sources=.

# Encoding of the source code. Default is default system encoding
sonar.sourceEncoding=UTF-8

# Set the language of the source code to analyze
# 不设置则默认分析多种语言
sonar.language = js
```
6）、然后到scanner的bin目录下运行sonar-scanner.bat 
 
### 3、汉化
登录到系统中，在页面上找到Administration > Marketplace，在搜索框中输入chinese，会出现一个Chinese Pack，点击右侧的install按钮进行安装。
安装成功后，会提示重启 SonarQube 服务器。
只需要等提示框消失后页面就已经显示中文了。

